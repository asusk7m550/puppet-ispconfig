<?php

$function_list['server_get,get_function_list,client_templates_get_all,server_get_serverid_by_ip,server_ip_get,server_ip_add,server_ip_update,server_ip_delete'] = 'Server functions';
$function_list['admin_record_permissions'] = 'Record permission changes';

?>
