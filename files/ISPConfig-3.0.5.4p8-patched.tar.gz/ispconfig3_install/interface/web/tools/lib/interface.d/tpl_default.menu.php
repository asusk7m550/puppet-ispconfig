<?php

// No settings yet
//$items[] = array(   'title'     => 'Default Theme',
//                    'target'  => 'content',
//                    'link' => 'tools/tpl_default.php',
//                    'html_id'   => 'tpl_default');
?>
